#include <iostream>

using namespace std;
void transferMoney(){
    cout << "Transfer Money Options:\n";
    cout << "1. Send Money\n";
    cout << "2. Receive Money\n";
    cout << "3. Check Balance\n";
    cout << "0. Go back\n";
    
    int option;
    cin >> option;
    
    if(option == 1){
        // Send money code here
        transferMoney();
    }
    else if(option == 2){
        // Receive money code here
        transferMoney();
    }
    else if(option == 3){
        // Check balance code here
        transferMoney();
    }
    else if(option == 0){
        return;
    }
    else{
        cout << "Invalid option. Please try again.\n";
        transferMoney();
    }
}

void myWallet(){
    cout << "My Wallet Options:\n";
    cout << "1. Check Balance\n";
    cout << "2. Add Money\n";
    cout << "3. Withdraw Money\n";
    cout << "0. Go back\n";
    
    int option;
    cin >> option;
    
    if(option == 1){
        // Check balance code here
        myWallet();
    }
    else if(option == 2){
        // Add money code here
        myWallet();
    }
    else if(option == 3){
        // Withdraw money code here
        myWallet();
    }
    else if(option == 0){
        return;
    }
    else{
        cout << "Invalid option. Please try again.\n";
        myWallet();
    }
}

int main(){
    cout << "Welcome to MTN Mobile Money System!\n";
    cout << "Enter *170# to continue.\n";
    
    string input;
    cin >> input;
    
    if(input == "*170#"){
        cout << "Main Menu:\n";
        cout << "1. Transfer Money\n";
        cout << "2. My Wallet\n";
        cout << "0. Exit\n";
        
        int option;
        cin >> option;
        
        if(option == 1){
            transferMoney();
        }
        else if(option == 2){
            myWallet();
        }
        else if(option == 0){
            cout << "Thank you for using MTN Mobile Money System!\n";
        }
        else{
            cout << "Invalid option. Please try again.\n";
        }
    }
    else{
        cout << "Invalid input. Please try again.\n";
    }	
	
	return 0;
}
